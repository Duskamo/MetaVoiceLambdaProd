/*
install on heroku:

$ sudo su
$ cd /home/leo/node.js/scott_lamda/heroku/task1/
$ nvm use 8.9.4
$ heroku login
$ heroku create
$ git add --all
$ git commit -m "init"
$ git push heroku master

https://cryptic-river-76762.herokuapp.com/


Task1 EndPoint (create dynamic lambda from code & credentials passed in request body as JSON):
Method: POST

https://cryptic-river-76762.herokuapp.com/task1/
{
	"Code": "def create_response(text, shouldEndSession):\n    return {\n        'version': '1.0',\n        'sessionAttributes': {},\n        'response': {\n          'outputSpeech': {\n              'type': 'PlainText',\n              'text': text\n          },\n          'card': {\n              'type': 'Simple',\n              'title': 'testSkill',\n              'content': text\n          },\n          'reprompt': {\n              'outputSpeech': {\n                  'type': 'PlainText',\n                  'text': \"text\"\n              }\n          },\n          'shouldEndSession': shouldEndSession\n        }\n    }\n\n\ndef lambda_handler(event, context):\n\n    #on launch request prompt user to ask for help\n    if event['request']['type'] == 'LaunchRequest':\n        return create_response('If you dont know how to use me you can ask for help by saying help', False)\n\n    #give user utterances\n    elif event['request']['intent']['name'] == 'Help':\n        return create_response('There are several commands, try saying utterance 1', False)\n\n    #end session\n    elif event['request']['type'] == 'SessionEndedRequest':\n        return create_response('', True)\n\n    #end session\n    elif event['request']['intent']['name'] == 'endSession':\n        return create_response('', True)\n\n    #user defined intents\n    #paste content here\n    elif event['request']['intent']['name'] == 'intent':\n        return create_response('Response', True)\n\n",
	"Handler": "index.create_response",
	"Runtime": "python2.7",
	"AccessKeyId": "AKIAIOOBN2ZM5QDSBW7A",
	"SecretAccessKey": "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",
	"Role":	"arn:aws:iam::504111962182:role/service-role/role_api1",
	"Region": "us-east-1",
	"Timeout": 30
}

Task2 :
https://cryptic-river-76762.herokuapp.com/task2/
{
	"AccessKeyId": "amzn1.application-oa2-client.ede7fbc64249410d9302a9983a75ec50",
	"SecretAccessKey": "d79ab79d312058c1cea9c90f82582878bfde69d383157023e0caa98c2b8bc182",
	"FunctionARN":	"arn:aws:lambda:us-east-1:504111962182:function:dynamic_function_1516435752808",
	"Manifest":  {
			"publishingInformation": {
				"locales": {
					"en-US": {
						"summary": "This is a sample Alexa skill.",
						"examplePhrases": [
							"Alexa, open sample skill.",
							"Alexa, turn on kitchen lights.",
							"Alexa, blink kitchen lights."
						],
						"keywords": [
							"Smart Home",
							"Lights",
							"Smart Devices"
						],
						"name": "Sample custom skill name.",
						"description": "This skill has basic and advanced smart devices control features."
					}
				},
				"isAvailableWorldwide": false,
				"testingInstructions": "1) Say 'Alexa, discover my devices' 2) Say 'Alexa, turn on sample lights'",
				"category": "SMART_HOME",
				"distributionCountries": [
					"US",
					"GB"
				]
			},
			"apis": {
				"custom": {
					"endpoint": {
						"uri": ""
					}
				}
			},
			"manifestVersion": "1.0",
			"privacyAndCompliance": {
				"allowsPurchases": false,
				"locales": {
					"en-US": {
						"termsOfUseUrl": "http://www.termsofuse.sampleskill.com",
						"privacyPolicyUrl": "http://www.myprivacypolicy.sampleskill.com"
					}
				},
				"isExportCompliant": true,
				"isChildDirected": false,
				"usesPersonalInfo": false
			}
		}
	}
}

https://cryptic-river-76762.herokuapp.com/log/

https://cryptic-river-76762.herokuapp.com/logreset/

GIT:
https://git.heroku.com/cryptic-river-76762.git
 */
const APP_VERSION = "2.1";
var fs = require("fs");
var winston = require("winston");
var sha1 = require('sha1');
var rp = require("request-promise");
const logger = winston.createLogger({
	level: 'info',
	format: winston.format.json(),
	transports: [
		//
		// - Write to all logs with level `info` and below to `combined.log`
		// - Write all logs error (and below) to `error.log`.
		//
//		new winston.transports.File({ filename: 'error.log', level: 'error' }),
		new winston.transports.File({ filename: 'combined.log' })
	]
});
logger.add(new winston.transports.Console({
	format: winston.format.simple()
}));
var express = require("express");
var bodyParser = require("body-parser");
var app = express();
var port = process.env.PORT || 5000;
var alexaAPI = "https://api.amazonalexa.com/v0";
var awsLoginAPI = "https://api.amazon.com";
const baseURL = "https://cryptic-river-76762.herokuapp.com";

app.use(function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	next();
});


app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/', function(request, response) {
  response.status(200).send('App Version = '+APP_VERSION);
});

app.get('/log/', function(request, response) {
	
	var content = fs.readFileSync("combined.log");
	response.status(200).send(content);
});

app.get('/logreset/', function(request, response) {
	
	try { fs.unlinkFileSync("combined.log"); } catch(e){};
	response.status(200).send("Log deleted!");
});

app.get("/task2/", function (request, response){
	
	var content = "" + fs.readFileSync("task2.html");
	content = content.replace("{APP_VERSION}",APP_VERSION);
	response.status(200).send(content);
});

function createMemoryZipFromFunctionCode(code, callback) {
	/*
			var dotIndex = handler.indexOf('.');
			var fileName = handler.substring(0, dotIndex);
			var handlerFunctionName = handler.substring(dotIndex + 1, handler.length);
			var echoLambdaFunction =
				"'use strict';\n" +
				"exports." + handlerFunctionName + " = function(event, context) {\n" +
				"   console.log('Event:', JSON.stringify(event));\n" +
				"   context.succeed(event);\n" +
				"};";
	*/
	var JSZip = require('jszip');
	var zip = new JSZip();
	zip.file('index.py', code);
	zip.generateAsync({type:"nodebuffer"})
		.then(function (content) {
			// use content
			callback(content);
		});
	//
}


/* Task1: */
app.post('/task1/', function(request, response){
//	console.log(request.body);      // your JSON
	if (!request.body.hasOwnProperty("Runtime")) {
		response.status(400).send({"Error": "Runtime was not passed!"});
	}
	if (!request.body.hasOwnProperty("Role")) {
		response.status(400).send({"Error": "Role was not passed!"});
	}
	if (!request.body.hasOwnProperty("Code")) {
		response.status(400).send({"Error": "Code was not passed!"});
	}
	if (!request.body.hasOwnProperty("AccessKeyId")) {
		response.status(400).send({"Error": "AccessKeyId was not passed!"});
	}
	if (!request.body.hasOwnProperty("SecretAccessKey")) {
		response.status(400).send({"Error": "SecretAccessKey was not passed!"});
	}
	if (!request.body.hasOwnProperty("Region")) {
		response.status(400).send({"Error": "Region was not passed!"});
	}

	var AWS = require('aws-sdk');
	var credentialsTask1 = './.credentials_task1_'+(new Date().getTime())+'.json';
	fs.writeFileSync(credentialsTask1, JSON.stringify({
		accessKeyId: 			request.body.AccessKeyId,
		secretAccessKey:	request.body.SecretAccessKey,
		region: 					request.body.Region

	},"utf-8"));
	AWS.config.loadFromPath(credentialsTask1);
	try {
		fs.unlinkSync(credentialsTask1);
	} catch(e){}
	var lambda = new AWS.Lambda({
		apiVersion: 			'2015-03-31',
		region: 					request.body.Region
	});

	var functionName = "dynamic_function_"+(new Date().getTime());

	createMemoryZipFromFunctionCode(request.body.Code, function (ZipContent){
		var params = {
			Code: 				{"ZipFile": ZipContent},
			Description: 	"Dynamic Lambda Function "+functionName,
			FunctionName: functionName,
			Handler: 			request.body.Handler || "index.handler", // is of the form of the name of your source file and then name of your function handler
			MemorySize: 	128,
			Publish: 			true,
			Role: 				request.body.Role, // replace with the actual arn of the execution role you created
			Runtime: 			request.body.Runtime,
			Timeout: 			request.body.Timeout || 30,
			VpcConfig: {
			}
		};
		console.log(params);
		lambda.createFunction(params, function(err, data) {
			if (err) {
				// Lambda creation failed, do not provide the physicalResourceId
				response.status(401).send({"Error": "Lamda function creation failed!", "AWS_error": err});
			}
			else {
				// Lambda creation succeeded, provide functionName as physicalResourceId so that this stack can delete it
				response.status(200).send(data);    // echo the result back
			}
		});
	});
});


function getVendorID(credentials){
	logger.info(">getVendorID", credentials);
	var options = {
		uri: alexaAPI + "/vendors",
		headers: {
			'User-Agent':  		'Request-Promise',
			'Authorization':  credentials.access_token
		},
		json: true // Automatically parses the JSON string in the response
	};
	logger.info("<getVendorID", options);
	return rp(options);
//	return new Promise(function (resolve, reject) {
}

function refreshToken(credentials, response){
	logger.info(">refreshToken", credentials);
	var options = {
		method: "POST",
		uri: awsLoginAPI + "/auth/o2/token",
		form: {
			client_id:			credentials.accessKeyId,
			client_secret:	credentials.secretAccessKey,
			grant_type:		 	'refresh_token',
			refresh_token:	credentials.refresh_token
		},
		headers: {
			'User-Agent':  		'Request-Promise'
		},
		json: true // Automatically parses the JSON string in the response
	};
	logger.info("<refreshToken", options);
	return rp(options);
}

function doTask2(credentials, response){
logger.info(">doTask2", credentials);
	getVendorID(credentials).then(function (vendors) {
logger.info("1.doTask2 vendors",vendors);
		var vendorID = vendors.vendors[0].id;
logger.info("2.doTask2 vendorID = "+vendorID);
		// create Alexa skill
		createAlexaSkill(credentials, response, vendorID );
	})
	.catch(function (err) {
logger.error("getVendorID error",err);
		// need refresh token?
		refreshToken(credentials, response).then(function ( new_credentials ){
logger.info("<refreshToken", new_credentials, credentials);
			credentials.access_token = new_credentials.access_token;
			credentials.refresh_token = new_credentials.refresh_token;
			
			var clientID = sha1(credentials.accessKeyId);
			var credentialsTask2 = "./.credentials_task2_" + clientID +".json";
			fs.writeFileSync(credentialsTask2, JSON.stringify({
					accessKeyId: 			credentials.AccessKeyId,
					secretAccessKey:	credentials.SecretAccessKey,
					access_token:			credentials.access_token,
					refresh_token:		credentials.refresh_token,
					manifest:					credentials.Manifest,
					functionARN: 			credentials.FunctionARN
			}), "utf-8");
logger.info("<refreshToken credentials saved!", credentials);
			doTask2(credentials, response);
		}).catch(function (err) {
logger.error({"Error": "Refresh token failed to refresh!","AWS_error": err});
			response.status(401).send({"Error": "Refresh token failed to refresh!","AWS_error": err});
		});
	});

}

function createAlexaSkill(credentials, response, vendorID){
logger.info(">createAlexaSkill vendor = "+vendorID, credentials);
	var manifest = {
		"vendorId": vendorID,
		"skillManifest": credentials.manifest
	};
	manifest.skillManifest.apis.custom.endpoint.uri = credentials.functionARN;
	logger.info("1.createAlexaSkill",manifest);
	var options = {
		method: "POST",
		uri: alexaAPI + "/skills",
		body: manifest,
		headers: {
			'User-Agent':  		'Request-Promise',
			'Authorization':  credentials.access_token
			/*			'content-type': 'application/x-www-form-urlencoded'*/
		},
		json: true // Automatically parses the JSON string in the response
	};
logger.info("2.createAlexaSkill",options);
	rp(options).then(function (res){
logger.info("<Alexa Skill Created!!!",res);
		response.status(200).send(res);
	}).catch(function (err){
logger.error({"Error": "Manifest was not accepted by AWS!","AWS_error": err});
		response.status(500).send({"Error": "Manifest was not accepted by AWS!","AWS_error": err});
	});
}



/* Task1: */
app.post('/task2/', function(request, response) {
logger.info(">task2",request.body);
	if (!request.body.hasOwnProperty("AccessKeyId")) {
logger.error({"Error": "AccessKeyId was not passed!"});
		response.status(400).send({"Error": "AccessKeyId was not passed!"});
		return;
	}
	if (!request.body.hasOwnProperty("SecretAccessKey")) {
logger.error({"Error": "SecretAccessKey was not passed!"});
		response.status(400).send({"Error": "SecretAccessKey was not passed!"});
		return;
	}
	if (!request.body.hasOwnProperty("FunctionARN")) {
logger.error({"Error": "FunctionARN was not passed!"});
		response.status(400).send({"Error": "FunctionARN was not passed!"});
		return;
	}
	if (!request.body.hasOwnProperty("Manifest")) {
logger.error({"Error": "Manifest was not passed!"});
		response.status(400).send({"Error": "Manifest was not passed!"});
		return;
	}
	try {
		var clientID = sha1(request.body.AccessKeyId);
		var credentialsTask2 = "./.credentials_task2_" + clientID +".json";
		if (!fs.existsSync(credentialsTask2)) {
			fs.writeFileSync(credentialsTask2, JSON.stringify({
				accessKeyId: 			request.body.AccessKeyId,
				secretAccessKey:	request.body.SecretAccessKey,
				manifest:					request.body.Manifest,
				functionARN: 			request.body.FunctionARN
			}), "utf-8");
			var url = "https://www.amazon.com/ap/oa?client_id=" + encodeURIComponent(request.body.AccessKeyId)
				+"&scope=alexa::ask:skills:readwrite&response_type=code&redirect_uri="
				+ encodeURIComponent(baseURL+"/task2_auth/");
			fs.writeFileSync(".client_id", (""+clientID), "utf-8" );
logger.info("<task2 redirect #1",url);
			response.status(200).send(url);
			return;
		}
		var content = fs.readFileSync(credentialsTask2);
		var credentials = JSON.parse(content);
logger.info("1.task2 credentials exists",credentials);
		credentials.functionARN = request.body.FunctionARN;
		credentials.manifest = request.body.Manifest;
		fs.writeFileSync(credentialsTask2, JSON.stringify({
			accessKeyId: 			credentials.accessKeyId,
			secretAccessKey:	credentials.secretAccessKey,
			access_token:			credentials.access_token,
			refresh_token:		credentials.refresh_token,
			manifest:					credentials.manifest,
			functionARN: 			credentials.functionARN
		}), "utf-8");
		if ((!credentials.hasOwnProperty("access_token")) || (!credentials.hasOwnProperty("refresh_token"))){
			var url = "https://www.amazon.com/ap/oa?client_id=" + encodeURIComponent(request.body.AccessKeyId)
				+"&scope=alexa::ask:skills:readwrite&response_type=code&redirect_uri="
				+ encodeURIComponent(baseURL+"/task2_auth/");
logger.info("<task2 redirect #2",url);
			fs.writeFileSync(".client_id", (""+clientID), "utf-8" );
			response.status(200).send(url);
			return;
		}
logger.info("<task2 calling doTask2...",credentials);
		// try post skill
		doTask2(credentials, response);
	} catch(e) {
logger.error("task2 ERROR",{"Error": e.message});
		response.status(500).send({"Error": e.message});
	}
//	console.log(request.body);      // your JSON
});

app.get('/task2_auth/', function(request, response) {
	var code = "" + request.param('code');
logger.info(">task2_auth",request.query,"code = "+code);
	if (code.length < 6) {
logger.error("task2_auth ERROR",{"Error": "Invalid code not passed!"});
		response.status(400).send({"Error": "Invalid code not passed!"});
	}
	
	var clientID = "";
	try {
		clientID = ""+fs.readFileSync(".client_id");
	} catch(e){
logger.error("Error in task2_auth",{"Error": "missing client_id"});
		response.status(400).send({"Error": "missing client_id"});
	}
		//request.param('clientId');
logger.info("1.task2_auth clientId = "+clientID);
	var credentialsTask2 = "./.credentials_task2_" + clientID +".json";
	if (!fs.existsSync(credentialsTask2)) {
logger.error("Error in task2_auth",{"Error": "Invalid clientId passed!"});
		response.status(400).send({"Error": "Invalid clientId passed!"});
	}
	try{
		var content = fs.readFileSync(credentialsTask2);
		var credentials = JSON.parse(content);
logger.info("2.task2_auth clientId = "+clientID+" code = "+code,credentials);
		var options = {
			method: "POST",
			uri: awsLoginAPI + "/auth/o2/token",
			form: {
				client_id:			credentials.accessKeyId,
				client_secret:	credentials.secretAccessKey,
				grant_type:		 	'authorization_code',
				redirect_uri:		baseURL+"/task2_auth/",
				code:						code
			},
			headers: {
				'User-Agent':  		'Request-Promise'
			},
			json: true // Automatically parses the JSON string in the response
		};
logger.info("3.task2_auth clientId = "+clientID+" code = "+code, options);
		rp(options).then(function (new_credentials){
logger.info("4.task2_auth clientId = "+clientID+" OK!!!",new_credentials,credentials);
			credentials.access_token = new_credentials.access_token;
			credentials.refresh_token = new_credentials.refresh_token;
			
			var clientID = sha1(credentials.accessKeyId);
			var credentialsTask2 = "./.credentials_task2_" + clientID +".json";
			fs.writeFileSync(credentialsTask2, JSON.stringify({
				accessKeyId: 			credentials.accessKeyId,
				secretAccessKey:	credentials.secretAccessKey,
				access_token:			credentials.access_token,
				refresh_token:		credentials.refresh_token,
				manifest:					credentials.manifest,
				functionARN: 			credentials.functionARN
			}), "utf-8");
logger.info("<task2_auth clientId = "+clientID+" calling doTask2...", credentials);
			doTask2(credentials, response);
		}).catch(function (err){
logger.error("Error in task2_auth",{"Error": "Failed get access_token!", "AWS_error": err});
			response.status(500).send({"Error": "Failed get access_token!", "AWS_error": err});
		});
	} catch(e){
logger.error("Error in task2_auth",{"Error": "Failed load credentials!"});
		response.status(400).send({"Error": "Failed load credentials!"});
	}
});


app.listen(port, function() {
	
	try {
		fs.unlinkFileSync("combined.log");
	} catch (e) {}
	logger.info("Server started at ", (new Date().toISOString()));
});