/*
call
npm install
and zip index.js + node_modules folder
before uploading to AWS Lambda

var event = {
	"Code": "'use strict';\nexports.handler = (event, context, callback) => \n{\n callback(null, JSON.stringify(event));\n };\n",
	"Runtime": "nodejs6.10",
	"Role":	"arn:aws:iam::504111962182:role/service-role/role_api1",
	"Timeout": 30
};


	Runtime: "python2.7",

*/
'use strict';

//var response = require('cfn-response');
var AWS = require('aws-sdk');
AWS.config.update({apiVersion: '2015-03-31'});

exports.handler = (event, context, callback) => {

	/**
	 * Helper function for creating the initial node.js "echo" Lambda.
	 *
	 * @param handler determines the name of the generated file as well as the name of the exported function in that file,
	 *  e.g. "index.handler".
	 */
	function createMemoryZipFromFunctionCode(code) {
/*
		var dotIndex = handler.indexOf('.');
		var fileName = handler.substring(0, dotIndex);
		var handlerFunctionName = handler.substring(dotIndex + 1, handler.length);
		var echoLambdaFunction =
			"'use strict';\n" +
			"exports." + handlerFunctionName + " = function(event, context) {\n" +
			"   console.log('Event:', JSON.stringify(event));\n" +
			"   context.succeed(event);\n" +
			"};";
*/
		var JSZip = require('jszip');
		var zip = new JSZip();
		zip.file('index.js', code);
		return zip.generate({type: 'nodebuffer'});
	}

	var lambda = new AWS.Lambda();
	var functionName = "dynamic_function_"+(new Date().getTime());
	var params = {
		Code: 				{"ZipFile": createMemoryZipFromFunctionCode(event.Code)},
		Description: 	"Dynamic Lambda Function "+functionName,
		FunctionName: functionName,
		Handler: 			event.Handler || "index.handler", // is of the form of the name of your source file and then name of your function handler
		MemorySize: 	128,
		Publish: 			true,
		Role: 				event.Role, // replace with the actual arn of the execution role you created
		Runtime: 			event.Runtime,
		Timeout: 			event.Timeout || 15,
		VpcConfig: {
		}
	};
//console.log(params);
	lambda.createFunction(params, function(err, data) {
		if (err) {
			// Lambda creation failed, do not provide the physicalResourceId
			callback(err);
		}
		else {
			// Lambda creation succeeded, provide functionName as physicalResourceId so that this stack can delete it
//			response.send(event, context, response.SUCCESS, data, functionName);
			callback(null, JSON.stringify(data));
		}
	});


};

